#!/usr/bin/env bash
# ============================================================================
# Black-box test script for the Smart Campus Lost & Found System.
# It compiles the program, then feeds scripted keyboard input to it inside a
# temporary copy of the project, so your real data/records.txt is never touched.
#
# Usage (from the project root):   bash tests/run_tests.sh
# ============================================================================

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$(mktemp -d)"
BINARY="$BUILD_DIR/lost_found"
PASS=0
FAIL=0

echo "Compiling..."
g++ -std=c++11 -Wall -Wextra -pedantic -o "$BINARY" "$PROJECT_ROOT/src/main.cpp" || { echo "COMPILE FAILED"; exit 1; }
echo "Compiled with no errors or warnings."
echo

# Create a fresh working copy of the project (sample data + empty reports folder).
fresh() {
    WORK="$(mktemp -d)"
    mkdir -p "$WORK/data" "$WORK/reports"
    cp "$PROJECT_ROOT/data/records.txt" "$WORK/data/records.txt"
}

# run <output-file> <line> <line> ...   -> runs the program with the given input lines.
run() {
    local out="$1"; shift
    printf '%s\n' "$@" | (cd "$WORK" && "$BINARY") > "$WORK/$out" 2>&1
}

check() {   # check <description> <condition-exit-code>
    if [ "$2" -eq 0 ]; then echo "PASS: $1"; PASS=$((PASS+1)); else echo "FAIL: $1"; FAIL=$((FAIL+1)); fi
}
has()     { grep -qF -- "$2" "$WORK/$1"; }          # has <file> <text>
hasnot()  { ! grep -qF -- "$2" "$WORK/$1"; }
line_of() { grep -nF -- "$2" "$WORK/$1" | head -1 | cut -d: -f1; }

# ---------------------------------------------------------------------------
echo "--- Module 1: Student Login ---"
fresh
run o.txt "bca2650" "Test Student" "10"
has o.txt "Login successful. Welcome, Test Student!"; check "T01 valid student login" $?
has o.txt "Logged in as: Test Student (BCA2650)";      check "T01b ID converted to upper case and shown in menu" $?

fresh
run o.txt "ab" "bad id!" "BCA2650" "R2D2" "T" "Test Student" "10"
has o.txt "Invalid ID";   check "T02 short / invalid student ID rejected" $?
has o.txt "Invalid name"; check "T02b invalid name (digits / 1 letter) rejected" $?
has o.txt "Welcome, Test Student!"; check "T02c login succeeds after corrections" $?

fresh
run o.txt "admin" "wrong" "0"
has o.txt "Wrong password"; check "T03 wrong admin password rejected" $?
has o.txt "Goodbye";        check "T03b typing 0 at login cancels the program" $?

fresh
run o.txt "ADMIN" "admin123" "10"
has o.txt "[ADMIN]"; check "T04 admin login with correct password" $?

fresh
run o.txt "STU101" "First User" "1" "STU202" "Second User" "" "10"
has o.txt "Logged in as: Second User (STU202)"; check "T05 switch user from menu (option 1)" $?

# ---------------------------------------------------------------------------
echo "--- Modules 2 & 3: Report Lost / Found ---"
fresh
run o.txt "STU101" "First User" "2" "3" "Room Keys|X" "Library" "" "" "10"
has o.txt "Your Item ID is 1009";                      check "T06 lost item gets next unique ID (1009)" $?
grep -q '^1009|LOST|Room Keys/X|Keys|Library|-|' "$WORK/data/records.txt"
check "T06b record saved; '|' replaced; empty description stored as '-'" $?

fresh
run o.txt "STU101" "First User" "3" "2" "BLACK WALLET" "library" "" "" "10"
has o.txt "Your Item ID is 1009";       check "T07 found item recorded" $?
has o.txt "possible match(es) found";   check "T07b instant possible-match hint shown (case-insensitive)" $?

fresh
run o.txt "STU101" "First User" "2" "9" "0" "2" "" "Wallet" "" "Cafe" "" "Brown" "" "10"
has o.txt "Number out of range";            check "T08 category outside 1-6 rejected" $?
has o.txt "Invalid input";                  check "T08b category '0' rejected as out of range/invalid" $?
has o.txt "This field cannot be empty";     check "T08c empty required field rejected" $?
has o.txt "Your Item ID is 1009";           check "T08d report completes after corrections" $?

fresh
LONGNAME="$(printf 'A%.0s' $(seq 1 40))"
run o.txt "STU101" "First User" "2" "6" "$LONGNAME" "Pen" "Cafe" "" "" "10"
has o.txt "Too long. Maximum 30 characters"; check "T09 over-long item name rejected" $?

# ---------------------------------------------------------------------------
echo "--- Module 4: Search ---"
fresh
run o.txt "STU101" "First User" "4" "1" "wallet" "0" "" "10"
has o.txt "2 record(s) found"; check "T10 search by name (partial, case-insensitive) -> 2 records" $?

fresh
run o.txt "STU101" "First User" "4" "2" "5" "1004" "" "10"
has o.txt "2 record(s) found";                       check "T11 search by category (Mobile Phone) -> 2 records" $?
has o.txt "Blue back cover, handed to guard";        check "T11b item details shown after search" $?

fresh
run o.txt "STU101" "First User" "4" "3" "LAB" "0" "" "10"
has o.txt "2 record(s) found"; check "T12 search by location 'LAB' -> 2 records" $?

fresh
run o.txt "STU101" "First User" "4" "1" "zzzz" "" "4" "7" "abc" "0" "10"
has o.txt "0 record(s) found"; check "T13 search with no result handled" $?
has o.txt "Invalid input";      check "T13b invalid search-menu input handled" $?

# ---------------------------------------------------------------------------
echo "--- Module 5: Auto Match ---"
fresh
run o.txt "BCA2601" "Aarav Sharma" "5" "1001" "1002" "" "8" "" "10"
has o.txt "2 possible match(es) found"; check "T14 auto match finds the 2 sample pairs" $?
A=$(line_of o.txt "Score: 100/100"); B=$(line_of o.txt "Score: 85/100")
[ -n "$A" ] && [ -n "$B" ] && [ "$A" -lt "$B" ]; check "T14b matches sorted by score (100 before 85)" $?
has o.txt "marked as RESOLVED";          check "T14c owner can mark matched pair RESOLVED" $?
has o.txt "Recovery rate     : 50.0%";   check "T14d statistics show updated recovery rate" $?
grep -q '^1001|LOST.*|RESOLVED$' "$WORK/data/records.txt" && grep -q '^1002|FOUND.*|RESOLVED$' "$WORK/data/records.txt"
check "T14e resolved status saved to file" $?

fresh
run o.txt "STU999" "Random Student" "5" "1003" "1004" "" "5" "1001" "1004" "" "10"
has o.txt "Only the owner, the finder or the admin"; check "T15 unrelated student cannot resolve a pair" $?
has o.txt "not in the match list";                   check "T15b pair not in match list is rejected" $?

fresh
run o.txt "STU101" "First User" "2" "3" "Hostel Keys" "Hostel Block A" "" "" "3" "3" "Room Keys" "Hostel Gate" "" "" "5" "0" "" "10"
has o.txt "possible match(es) found";    check "T16 newly reported found keys match existing lost keys" $?
has o.txt "Score: 65/100";               check "T16b partial name (35) + same category (30), different place = 65" $?

fresh
cd "$WORK" && printf '%s\n' "STU101" "First User" "2" "1" "Pink Bag" "Gym" "" "" "5" "" "10" | "$BINARY" > o2.txt 2>&1; cd - > /dev/null
has o2.txt "2 possible match(es) found"; check "T17 unrelated new item does not create extra matches" $?

# ---------------------------------------------------------------------------
echo "--- Module 6: View All Records / Sorting ---"
fresh
run o.txt "STU101" "First User" "6" "2" "1005" "" "10"
A=$(line_of o.txt "College ID Card"); B=$(line_of o.txt "Dell Laptop"); C=$(line_of o.txt "Samsung Mobile")
[ "$A" -lt "$B" ] && [ "$B" -lt "$C" ]; check "T18 sort by item name A-Z (College < Dell < Samsung)" $?
has o.txt "Total records: 8";                 check "T18b all 8 sample records displayed" $?
has o.txt "Reported by : Simran Kaur (BCA2605)"; check "T18c full details of item 1005 shown" $?

fresh
run o.txt "STU101" "First User" "6" "4" "9999" "" "10"
L7=$(line_of o.txt "1007  LOST"); L1=$(line_of o.txt "1001  LOST")
[ "$L7" -lt "$L1" ]; check "T19 sort by date: newest (1007) before oldest (1001)" $?
has o.txt "No record with ID 9999"; check "T19b unknown ID in detail prompt handled" $?

fresh
run o.txt "STU101" "First User" "6" "5" "0" "" "10"
F=$(line_of o.txt "1002  FOUND"); L=$(line_of o.txt "1001  LOST")
[ "$F" -lt "$L" ]; check "T20 sort by type: FOUND before LOST" $?

fresh
run o.txt "STU101" "First User" "6" "3" "0" "" "10"
A=$(line_of o.txt "College"); B=$(line_of o.txt "Dell Laptop")
has o.txt "ID Card"; check "T21 sort by category runs" $?

# ---------------------------------------------------------------------------
echo "--- Module 7: Delete ---"
fresh
run o.txt "STU999" "Random Student" "7" "1001" "" "10"
has o.txt "Access denied";  check "T22 student cannot delete another student's record" $?
grep -q '^1001|' "$WORK/data/records.txt"; check "T22b record still in file after denied delete" $?

fresh
run o.txt "BCA2601" "Aarav Sharma" "7" "1001" "n" "" "7" "1001" "maybe" "y" "" "7" "5555" "" "7" "0" "" "10"
has o.txt "Delete cancelled. Record kept."; check "T23 answering 'n' keeps the record" $?
has o.txt "Please type y or n";              check "T23b invalid confirmation answer re-asked" $?
has o.txt "Record 1001 deleted";             check "T23c owner deletes own record after 'y'" $?
grep -q '^1001|' "$WORK/data/records.txt"; [ $? -ne 0 ]; check "T23d deleted record removed from file" $?
has o.txt "No record found with ID 5555";    check "T23e deleting unknown ID handled" $?
has o.txt "Delete cancelled.";               check "T23f 0 cancels delete" $?

fresh
run o.txt "ADMIN" "admin123" "7" "1008" "y" "" "10"
has o.txt "Record 1008 deleted"; check "T24 admin can delete any record" $?

# ---------------------------------------------------------------------------
echo "--- Module 8: Statistics ---"
fresh
run o.txt "STU101" "First User" "8" "" "10"
has o.txt "Total records     : 8";   check "T25 total records = 8" $?
has o.txt "Lost items        : 4";   check "T25b lost = 4" $?
has o.txt "Found items       : 4";   check "T25c found = 4" $?
has o.txt "Resolved records  : 2";   check "T25d resolved = 2" $?
has o.txt "Recovery rate     : 25.0%"; check "T25e recovery rate = 25.0%" $?

# ---------------------------------------------------------------------------
echo "--- Module 9: Export ---"
fresh
run o.txt "STU101" "First User" "2" "1" "Pink Bag" "Gym" 'Red, "big" bag' "" "9" "" "10"
has o.txt "9 record(s) exported to reports/item_report.csv"; check "T26 export reports record count" $?
[ "$(wc -l < "$WORK/reports/item_report.csv")" -eq 10 ]; check "T26b CSV has header + 9 data rows" $?
head -1 "$WORK/reports/item_report.csv" | grep -qF "ID,Type,Item Name,Category"; check "T26c CSV header correct" $?
grep -qF '"Red, ""big"" bag"' "$WORK/reports/item_report.csv"; check "T26d commas and quotes escaped correctly in CSV" $?
cp "$WORK/reports/item_report.csv" "$BUILD_DIR/export_sample.csv"

# ---------------------------------------------------------------------------
echo "--- Persistence & restart ---"
fresh
run o1.txt "STU101" "First User" "2" "2" "Silver Wallet" "Bus Stop" "Zip pocket" "" "10"
run o2.txt "STU202" "Second User" "6" "1" "1009" "" "3" "2" "Gold Ring" "Bus Stop" "" "" "10"
has o2.txt "Silver Wallet";              check "T27 record saved earlier is visible after restart" $?
has o2.txt "Your Item ID is 1010";       check "T27b IDs continue (1010) after restart - no duplicates" $?
cut -d'|' -f1 "$WORK/data/records.txt" | grep -v '^#' | sort | uniq -d | wc -l | grep -qx 0
check "T27c no duplicate IDs in data file" $?

# ---------------------------------------------------------------------------
echo "--- Invalid input & error handling ---"
fresh
run o.txt "STU101" "First User" "abc" "" "0" "11" "-1" "1.5" "10"
has o.txt "Invalid input";      check "T28 non-numeric / empty / negative / decimal menu input rejected" $?
has o.txt "Number out of range"; check "T28b out-of-range menu number rejected" $?
has o.txt "Goodbye";            check "T28c program still exits normally afterwards" $?

fresh
run o.txt "STU101" "First User"
has o.txt "Input ended";        check "T29 end of input handled without infinite loop" $?

fresh
printf '%s\n' 'garbage line' '1001|LOST|Duplicate|Wallet|Lib|x|2026-01-01|A|B|OPEN' '2000|BROKEN|X|Wallet|Lib|x|2026-01-01|A|B|OPEN' '3000|LOST|Short|Wallet' 'abc|LOST|X|Wallet|Lib|x|2026-01-01|A|B|OPEN' >> "$WORK/data/records.txt"
run o.txt "STU101" "First User" "10"
has o.txt "Loaded 8 record(s)";               check "T30 corrupt/duplicate lines skipped, 8 valid records loaded" $?
has o.txt "5 invalid/duplicate line(s) skipped"; check "T30b skipped-line count reported" $?

fresh
rm "$WORK/data/records.txt"
run o.txt "STU101" "First User" "8" "" "2" "1" "Pen" "Cafe" "" "" "10"
has o.txt "No data file found";   check "T31 missing data file handled" $?
has o.txt "Total records     : 0"; check "T31b statistics work on an empty database (no crash)" $?
grep -q '^1001|LOST|Pen' "$WORK/data/records.txt"; check "T31c data file re-created, first ID is 1001" $?

fresh
rm -rf "$WORK/data" "$WORK/reports"
run o.txt "STU101" "First User" "2" "1" "Pen" "Cafe" "" "" "6" "" "9" "" "10"
has o.txt "Could not write to 'data/records.txt'";   check "T32 save failure reported (folder missing)" $?
has o.txt "The database is empty";                   check "T32b failed save rolled back (no ghost record)" $?
has o.txt "Could not create 'reports/item_report.csv'"; check "T32c export failure reported" $?

# ---------------------------------------------------------------------------
echo
echo "RESULT: $PASS passed, $FAIL failed"
cp "$BUILD_DIR/export_sample.csv" /tmp/export_sample.csv 2>/dev/null
[ "$FAIL" -eq 0 ]
